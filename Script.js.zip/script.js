/* =====================================================
   ECOCOLLECT - RESIDENT SCRIPT
   Handles:
   1. Waste collection request submission
   2. Saving requests
   3. Checking request status
   ===================================================== */

const STORAGE_KEY = "ecocollectRequests";


/* =====================================================
   START AFTER PAGE LOAD
   ===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    /* =================================================
       GET FORM
       ================================================= */

    const residentForm = document.getElementById("residentForm");


    /* =================================================
       SUBMIT WASTE COLLECTION REQUEST
       ================================================= */

    if (residentForm) {

        residentForm.addEventListener("submit", function (event) {

            event.preventDefault();


            /* -----------------------------------------
               GET FORM VALUES
               ----------------------------------------- */

            const fullname =
                document.getElementById("fullname").value.trim();

            const email =
                document.getElementById("email").value.trim();

            const phone =
                document.getElementById("phone").value.trim();

            const address =
                document.getElementById("address").value.trim();

            const area =
                document.getElementById("area").value;

            const collectionDate =
                document.getElementById("collectionDate").value;

            const collectionTime =
                document.getElementById("collectionTime").value;

            const wasteType =
                document.getElementById("wasteType").value;


            /* -----------------------------------------
               CHECK REQUIRED FIELDS
               ----------------------------------------- */

            if (
                !fullname ||
                !email ||
                !phone ||
                !address ||
                !area ||
                !collectionDate ||
                !collectionTime ||
                !wasteType
            ) {

                alert("Please complete all required fields.");

                return;
            }


            /* -----------------------------------------
               CREATE REQUEST
               ----------------------------------------- */

            const request = {

                id: Date.now(),

                resident: fullname,

                email: email,

                phone: phone,

                address: address,

                area: area,

                collectionDate: collectionDate,

                collectionTime: collectionTime,

                wasteType: wasteType,

                status: "Pending",

                createdAt: new Date().toISOString()

            };


            /* -----------------------------------------
               GET EXISTING REQUESTS
               ----------------------------------------- */

            let requests = [];

            try {

                requests =
                    JSON.parse(
                        localStorage.getItem(STORAGE_KEY) || "[]"
                    );

                if (!Array.isArray(requests)) {
                    requests = [];
                }

            } catch (error) {

                requests = [];

            }


            /* -----------------------------------------
               ADD NEW REQUEST
               ----------------------------------------- */

            requests.push(request);


            /* -----------------------------------------
               SAVE REQUEST
               ----------------------------------------- */

            try {

                localStorage.setItem(
                    STORAGE_KEY,
                    JSON.stringify(requests)
                );

            } catch (error) {

                alert(
                    "Unable to save your request. Please try again."
                );

                return;
            }


            /* -----------------------------------------
               SUCCESS MESSAGE
               ----------------------------------------- */

            alert(
                "Waste collection request submitted successfully!\n\n" +
                "Your request status is: Pending"
            );


            /* -----------------------------------------
               CLEAR FORM
               ----------------------------------------- */

            residentForm.reset();


            /* -----------------------------------------
               SHOW STATUS SECTION
               ----------------------------------------- */

            const statusSection =
                document.getElementById("status");

            if (statusSection) {

                statusSection.scrollIntoView({
                    behavior: "smooth"
                });

            }

        });

    }


    /* =================================================
       CHECK STATUS BUTTON
       ================================================= */

    const checkStatusBtn =
        document.getElementById("checkStatusBtn");

    const statusSearch =
        document.getElementById("statusSearch");

    const statusResult =
        document.getElementById("statusResult");


    if (checkStatusBtn) {

        checkStatusBtn.addEventListener("click", function () {

            const searchValue =
                statusSearch.value.trim().toLowerCase();


            /* -----------------------------------------
               CHECK SEARCH FIELD
               ----------------------------------------- */

            if (!searchValue) {

                statusResult.innerHTML =
                    "<div style='color:#c62828;font-weight:bold;padding:15px;'>" +
                    "Please enter your email address or phone number." +
                    "</div>";

                return;
            }


            /* -----------------------------------------
               GET REQUESTS
               ----------------------------------------- */

            let requests = [];

            try {

                requests =
                    JSON.parse(
                        localStorage.getItem(STORAGE_KEY) || "[]"
                    );

                if (!Array.isArray(requests)) {
                    requests = [];
                }

            } catch (error) {

                requests = [];

            }


            /* -----------------------------------------
               FIND REQUEST
               ----------------------------------------- */

            const request =
                requests.find(function (item) {

                    const itemEmail =
                        String(item.email || "")
                            .trim()
                            .toLowerCase();

                    const itemPhone =
                        String(item.phone || "")
                            .trim()
                            .toLowerCase();

                    return (
                        itemEmail === searchValue ||
                        itemPhone === searchValue
                    );

                });


            /* -----------------------------------------
               REQUEST NOT FOUND
               ----------------------------------------- */

            if (!request) {

                statusResult.innerHTML =
                    "<div style='background:#fff3f3;" +
                    "padding:20px;border-radius:15px;" +
                    "color:#c62828;font-weight:bold;'>" +

                    "No waste collection request was found " +
                    "for this email or phone number." +

                    "</div>";

                return;
            }


            /* -----------------------------------------
               GET STATUS
               ----------------------------------------- */

            const status =
                request.status || "Pending";


            /* -----------------------------------------
               STATUS MESSAGE
               ----------------------------------------- */

            let message = "";


            if (status === "Pending") {

                message =
                    "Your request has been received and is waiting for approval.";

            } else if (status === "Approved") {

                message =
                    "Your waste collection request has been approved.";

            } else if (status === "Completed") {

                message =
                    "Your waste collection has been completed.";

            } else if (status === "Rejected") {

                message =
                    "Your waste collection request has been rejected.";

            } else {

                message =
                    "Your request is currently being processed.";

            }


            /* -----------------------------------------
               DISPLAY STATUS
               ----------------------------------------- */

            statusResult.innerHTML =

                "<div style='" +
                "background:#ffffff;" +
                "padding:25px;" +
                "border-radius:18px;" +
                "margin-top:20px;" +
                "text-align:left;" +
                "box-shadow:0 3px 15px rgba(0,0,0,0.08);'>" +

                "<h3 style='color:#176b3a;margin-bottom:15px;'>" +
                "Collection Request Found" +
                "</h3>" +

                "<p><strong>Resident:</strong> " +
                escapeHTML(request.resident) +
                "</p>" +

                "<p><strong>Area:</strong> " +
                escapeHTML(request.area) +
                "</p>" +

                "<p><strong>Collection Date:</strong> " +
                escapeHTML(request.collectionDate) +
                "</p>" +

                "<p><strong>Collection Time:</strong> " +
                escapeHTML(request.collectionTime) +
                "</p>" +

                "<p><strong>Waste Type:</strong> " +
                escapeHTML(request.wasteType) +
                "</p>" +

                "<p style='margin-top:15px;'>" +

                "<strong>Status:</strong> " +

                "<span style='" +
                "display:inline-block;" +
                "padding:7px 14px;" +
                "border-radius:20px;" +
                "background:#e8f5e9;" +
                "color:#176b3a;" +
                "font-weight:bold;" +
                "margin-left:5px;'>" +

                escapeHTML(status) +

                "</span>" +

                "</p>" +

                "<p style='margin-top:15px;color:#555;'>" +
                escapeHTML(message) +
                "</p>" +

                "</div>";

        });

    }


    /* =================================================
       ENTER KEY FOR STATUS SEARCH
       ================================================= */

    if (statusSearch && checkStatusBtn) {

        statusSearch.addEventListener("keydown", function (event) {

            if (event.key === "Enter") {

                event.preventDefault();

                checkStatusBtn.click();

            }

        });

    }

});


/* =====================================================
   SECURITY HELPER
   ===================================================== */

function escapeHTML(value) {

    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}